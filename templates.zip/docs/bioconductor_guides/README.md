# Bioconductor documentation

Definitely use the [Bioconductor package guidelines!](https://github.com/Bioconductor/Contributions
https://bioconductor.org/developers/package-guidelines/)

- [Bioconductor notebook vignette template](./bioconductor_vignette_template.Rmd)
- [Bioconductor example script template](./bioconductor_example_script.R)
