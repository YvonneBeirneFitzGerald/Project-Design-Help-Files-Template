# Template for Documentation

This repository is a template git repo that you can fill in with information about your own tool as you follow along with the [ITCR Documentation and Usability course](https://github.com/jhudsl/ITCR_Documentation_and_Usability).

This would be your landing page for your user!

First and foremost, you should [explain the Why of your tool!](Link to chapter that describes this).

For [Bioconductor specific guidance go here](./docs/bioconductor-guides).
